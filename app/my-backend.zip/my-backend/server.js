require('dotenv').config();  // Подтягиваем переменные из .env

const express = require('express');
const { Pool } = require('pg');
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer');
// const cors = require('cors'); // если нужно

const app = express();
const port = process.env.PORT || 3000;

// Если нужен CORS:
// app.use(cors());

// Чтобы читать JSON-тело запроса
app.use(express.json());

// Подключение к PostgreSQL через пул соединений
const pool = new Pool({
  host: process.env.DB_HOST,
  database: process.env.DB_NAME,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  port: 5432, // или тот, который требует Neon (обычно 5432/6432)
  ssl: {
    rejectUnauthorized: false
  }
});

// ---- Nodemailer: создаём транспорт для SMTP ----
const transporter = nodemailer.createTransport({
  host: process.env.EMAIL_HOST,
  port: parseInt(process.env.EMAIL_PORT) || 587,
  secure: false,  // true, если порт 465
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

// Пример эндпоинта для проверки, что сервер работает
app.get('/', (req, res) => {
  res.send('Server is running');
});

/**
 * Эндпоинт для логина
 * Ожидаем в теле запроса: { "email": "...", "password": "..." }
 * Если ок - выдаём JWT токен и сообщение об успехе
 */
app.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    // 1. Находим пользователя по email
    const findUserQuery = 'SELECT * FROM client WHERE email = $1';
    const result = await pool.query(findUserQuery, [email]);

    if (result.rows.length === 0) {
      return res.status(401).json({ success: false, message: 'User not found' });
    }

    const user = result.rows[0];

    // 2. Проверяем пароль
    if (password !== user.password) {
      return res.status(401).json({ success: false, message: 'Invalid credentials' });
    }

    // 3. Пароль совпал, генерируем JWT
    const token = jwt.sign(
      { userId: user.id, email: user.email },
      process.env.JWT_SECRET,
      { expiresIn: '1h' } // токен живёт 1 час
    );

    // Возвращаем токен и userId (столбец id из таблицы client)
    return res.json({
      success: true,
      message: 'Login successful',
      token: token,
      userId: user.id
    });
  } catch (error) {
    console.error('Error in /login:', error);
    return res.status(500).json({
      success: false,
      message: 'Server error',
      error: error.message
    });
  }
});


/**
 * Эндпоинт для регистрации (пример, если нужно)
 * Принимает email и пароль и сохраняет в базу данных без хэширования.
 */
app.post('/register', async (req, res) => {
  try {
    // Извлекаем поля из тела запроса
    const { email, password, name, number } = req.body;

    // Проверяем, есть ли уже пользователь с таким email
    const checkUserQuery = 'SELECT * FROM client WHERE email = $1';
    const existingUser = await pool.query(checkUserQuery, [email]);
    if (existingUser.rows.length > 0) {
      return res.status(400).json({ success: false, message: 'Email already exists' });
    }

    // Вставляем нового пользователя в таблицу client
    const insertUserQuery = `
      INSERT INTO client (email, password)
      VALUES ($1, $2)
      RETURNING id
    `;
    const newUser = await pool.query(insertUserQuery, [email, password]);
    const userId = newUser.rows[0].id; // Получаем сгенерированный id

    // Вставляем запись в таблицу profileinformation, связывая по profile_id
    // Обратите внимание: если ваши столбцы называются с заглавными буквами ("Location", "Name"),
    // убедитесь, что они так же созданы в БД или, лучше, используйте нижний регистр.
    const insertProfileQuery = `
      INSERT INTO profileinformation ("Location", "Name", phonenumber, profile_id)
      VALUES ($1, $2, $3, $4)
    `;
    await pool.query(insertProfileQuery, ['Almaty', name, number, userId]);

    // Возвращаем ответ с userId
    return res.json({
      success: true,
      message: 'User registered',
      userId: userId
    });
  } catch (error) {
    console.error('Error in /register:', error);
    return res.status(500).json({
      success: false,
      message: 'Server error',
      error: error.message
    });
  }
});



// =========== 1) Эндпоинт для ЗАПРОСА СБРОСА (forgot-password) ===========
app.post('/forgot-password', async (req, res) => {
  try {
    const { email } = req.body;

    // 1. Найдём пользователя по email
    const userQuery = 'SELECT id FROM client WHERE email = $1';
    const userResult = await pool.query(userQuery, [email]);

    if (userResult.rows.length === 0) {
      return res
        .status(404)
        .json({ success: false, message: 'User with this email not found' });
    }

    const userId = userResult.rows[0].id;

    // 2. Генерируем код (6 цифр, например)
    const resetCode = Math.floor(1000 + Math.random() * 9000).toString();

    // 3. Установим срок действия (15 минут)
    const expiresAt = new Date(Date.now() + 15 * 60 * 1000);

    // 4. Сохраним запись в таблицу password_resets
    // (Сначала можно удалить старые коды, если были)
    await pool.query('DELETE FROM password_resets WHERE user_id = $1', [userId]);

    const insertQuery = `
      INSERT INTO password_resets (user_id, reset_code, expires_at, used)
      VALUES ($1, $2, $3, $4)
    `;
    await pool.query(insertQuery, [userId, resetCode, expiresAt, false]);

    // 5. Отправляем email с кодом
    const mailOptions = {
      from: process.env.EMAIL_USER,  // "от кого"
      to: email,                     // "кому"
      subject: 'Password Reset Code',
      text: `Ваш код для сброса пароля: ${resetCode}. Код действителен 15 минут.`
    };
    await transporter.sendMail(mailOptions);

    // 6. Возвращаем ответ клиенту
    return res.json({
      success: true,
      message: 'Reset code sent to email'
    });
  } catch (error) {
    console.error('Error in /forgot-password:', error);
    return res.status(500).json({ success: false, message: 'Server error' });
  }
});

// =========== 2) Эндпоинт для СБРОСА ПАРОЛЯ (reset-password) ===========
app.post('/reset-password', async (req, res) => {
  try {
    const { email, newPassword } = req.body;

    // Находим userId
    const userResult = await pool.query('SELECT id FROM client WHERE email=$1', [email]);
    if (userResult.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }
    const userId = userResult.rows[0].id;

    // Обновляем пароль
    await pool.query('UPDATE client SET password=$1 WHERE id=$2', [newPassword, userId]);

    // (При желании можем искать в password_resets и помечать used, если это нужно)
    return res.json({ success: true, message: 'Password has been reset' });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ success: false, message: 'Server error' });
  }
});


//Verify OTP Code in SERVER
app.post('/verify-code', async (req, res) => {
  try {
    const { email, code } = req.body;

    if (!email || !code) {
      return res.status(400).json({ success: false, message: "Missing email or code" });
    }

    // 1. Находим пользователя по email
    const userQuery = 'SELECT id FROM client WHERE email = $1';
    const userResult = await pool.query(userQuery, [email]);
    if (userResult.rows.length === 0) {
      return res.status(404).json({ success: false, message: "User not found" });
    }
    const userId = userResult.rows[0].id;

    // 2. Получаем последнюю запись для этого пользоватrеля из password_resets
    const resetQuery = `
      SELECT id, reset_code, expires_at, used
      FROM password_resets
      WHERE user_id = $1
      ORDER BY id DESC
      LIMIT 1
    `;
    const resetResult = await pool.query(resetQuery, [userId]);
    if (resetResult.rows.length === 0) {
      return res.status(400).json({ success: false, message: "No reset request found" });
    }
    const resetRecord = resetResult.rows[0];

    // 3. Проверяем, что код не использован
    if (resetRecord.used) {
      return res.status(400).json({ success: false, message: "Code already used" });
    }

    // 4. Проверяем, не просрочен ли код
    if (new Date() > new Date(resetRecord.expires_at)) {
      return res.status(400).json({ success: false, message: "Code has expired" });
    }

    // 5. Сравниваем сохранённый код с введённым
    if (resetRecord.reset_code !== code) {
      return res.status(400).json({ success: false, message: "Invalid code" });
    }

    // 6. Если всё совпадает, помечаем код как использованный
    const updateQuery = 'UPDATE password_resets SET used = true WHERE id = $1';
    await pool.query(updateQuery, [resetRecord.id]);

    return res.json({ success: true, message: "Code verified" });
  } catch (error) {
    console.error('Error in /verify-code:', error);
    return res.status(500).json({ success: false, message: "Server error" });
  }
});
//Get id from ProfileInformation
app.get('/profile/:id', async (req, res) => {
  try {
    const profileId = req.params.id;
    const query = `
      SELECT "Name" as name, phonenumber, "Location" as location
      FROM profileinformation
      WHERE profile_id = $1
    `;
    const result = await pool.query(query, [profileId]);

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Profile not found' });
    }

    res.json({ success: true, profile: result.rows[0] });
  } catch (error) {
    console.error('Error in /profile/:id:', error);
    res.status(500).json({
      success: false,
      message: 'Server error',
      error: error.message
    });
  }
});

// Change Contact Number
app.put('/profile/:id/number', async (req, res) => {
  try {
    const userId = req.params.id;          // ID пользователя из URL
    const { number } = req.body;           // Новый номер из тела запроса

    // Обновляем запись в базе
    const updateProfileQuery = `
      UPDATE profileinformation
      SET phonenumber = $1
      WHERE profile_id = $2
    `;
    await pool.query(updateProfileQuery, [number, userId]);

    return res.json({
      success: true,
      message: 'Contact number updated successfully'
    });
  } catch (error) {
    console.error('Error in /profile/:id/number:', error);
    return res.status(500).json({
      success: false,
      message: 'Server error',
      error: error.message
    });
  }
});

app.put('/profile/:id/name', async (req, res) => {
  try {
    const userId = req.params.id;       // ID пользователя из URL
    const { name } = req.body;          // Новый name из тела запроса

    // Обновляем запись в базе данных
    const updateProfileQuery = `
      UPDATE profileinformation
      SET "Name" = $1
      WHERE profile_id = $2
    `;
    await pool.query(updateProfileQuery, [name, userId]);

    return res.json({
      success: true,
      message: 'Name updated successfully'
    });
  } catch (error) {
    console.error('Error in /profile/:id/name:', error);
    return res.status(500).json({
      success: false,
      message: 'Server error',
      error: error.message
    });
  }
});

app.put('/client/:id/password', async (req, res) => {
  try {
    const userId = req.params.id;       // ID клиента из URL
    const { password } = req.body;        // Новый пароль из тела запроса

    // Обновляем пароль в таблице client
    const updatePasswordQuery = `
      UPDATE client
      SET password = $1
      WHERE id = $2
    `;
    await pool.query(updatePasswordQuery, [password, userId]);

    return res.json({
      success: true,
      message: 'Password updated successfully'
    });
  } catch (error) {
    console.error('Error in /client/:id/password:', error);
    return res.status(500).json({
      success: false,
      message: 'Server error',
      error: error.message
    });
  }
});


// Запуск сервера
app.listen(port, () => {
  console.log(`Server is running on http://0.0.0.0:${port}`);
});
